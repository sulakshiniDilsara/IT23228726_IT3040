// generate_excel.ts
import XLSX from 'xlsx';
import fs from 'fs';

const testCases = [
  {
    "TC ID": "Pos_Fun_0001",
    "Test case name": "Greeting",
    "Input length type": "S",
    "Input": "oyaata kohomadha?",
    "Expected output": "ඔයාට කොහොමද?",
    "Actual output": "ඔයාට කොහොමද?",
    "Status": "Pass",
    "Accuracy justification / Description": "Greeting meaning preserved",
    "What is covered by the test": "Greeting / request / response; Interrogative; S (≤30 characters); Accuracy validation"
  },
  // Add the remaining 36 test cases here
];

// Create a new workbook and worksheet
const wb = XLSX.utils.book_new();
const ws = XLSX.utils.json_to_sheet(testCases);
XLSX.utils.book_append_sheet(wb, ws, 'TestCases');

// Write Excel file
XLSX.writeFile(wb, 'IT23156210_TestCases.xlsx');

console.log('Excel file created!');

